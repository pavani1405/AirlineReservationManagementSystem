package com.mypackage.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Disabled;

import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.model.User;
import com.mypackage.demo.service.PassengerService;
import com.mypackage.demo.service.UserService;

@SpringBootTest
class AirlineReservationManagementSystemApplicationTests {
	
	@Autowired
	PassengerService passengerService;
	@Autowired
	UserService userService;
	@Disabled
	@Test
	public void addPassenger() {
		User user = userService.getUserById(5);
		Passenger passenger=new Passenger();
		passenger.setpFirstName("Varun");
		passenger.setpLastName("Reddy");
		passenger.setpAge(21);
		passenger.setpMobileNo("8790438445");
		passenger.setpGender("male");
		passenger.setpEmail("varunreddy@gmail.com");
		passenger.setpPassportNo("B768938");
		passenger.setpSeatNumber("E1");
		passenger.setUser(user);
		Passenger p1= this.passengerService.addPassenger(passenger);
		assertNotNull(p1);
	}
	
	@Disabled
	@Test
	public void deletePassenger() {
	this.passengerService.removePassengerById(119);
	System.out.println("Passenger is deleted Successfully");
	}
	
	@Disabled
	@Test
	public void testPassengerCount() {
		List<Passenger> passengerList=passengerService.getAllPassenger();
		assertTrue(passengerList.size()>100);
	}
	
	@Test
	public void getPassengerFirstNameBypId() {
		Passenger passenger=passengerService.getPassengerById(1);
		 assertNotNull(passenger); 
		    assertEquals("GUNA", passenger.getpFirstName());
	}
}
