package com.mypackage.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mypackage.demo.model.User;
import com.mypackage.demo.service.UserService;

@SpringBootTest
class UserTest {

	@Autowired
	UserService userService;
	
	@Disabled
	@Test
	public void addUserDetails() {
		User user=new User();
		user.setUserFirstName("Shaik");
		user.setUserLastName("anas");
		user.setUserAge(23);
		user.setUserEmail("Anas@gmail.com");
		user.setUserFavourite("A");
		user.setUserGender("Male");
		user.setUserMobileNo("8612345689");
		user.setUserPassportNo("B789065");
		user.setUserPassword("Anas@1234");
		User u1=this.userService.addUser(user);
		assertNotNull(u1);
	}

	@Disabled
	@Test
	public void deleteUserById() {
		this.userService.removeUserById(6);
		System.out.println("DeletedSuccessfully");
	}
	
	@Test
	public void getUserDetailsById() {
	    User user = userService.getUserById(4);
	    assertNotNull(user);
	    assertEquals(4, user.getUserId());
	    assertEquals("SHAIK", user.getUserFirstName()); 
	    assertEquals("MAAZ", user.getUserLastName()); 
	    assertEquals("maazshaik123@gmail.com", user.getUserEmail()); 
	}

}
