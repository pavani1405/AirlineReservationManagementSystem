package com.mypackage.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mypackage.demo.model.Flight;
import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.model.Seat;
import com.mypackage.demo.service.FlightService;
import com.mypackage.demo.service.SeatService;


@SpringBootTest
class SeatTest {

	@Autowired
	SeatService seatService;
	
	@Autowired
	FlightService flightService;
	
	@Disabled
	@Test
	public void addSeatDetails() {
		Seat seat=new Seat();
		
		seat.setClassType("Economy");
		seat.setFlight(null);
		seat.setSeatNumber("R1");
		seat.setSeatType("window");
		seat.setSeatPrice(2450);
		seat.setStatus("available");
		Seat s1= this.seatService.addSeat(seat);
		assertNotNull(s1);
	}
	
	@Disabled
	@Test
	public void deleteSeatById() {
		this.seatService.removeSeatById(117);
		System.out.println("Deleted successfully");
	}
	
	@Disabled
	@Test 
	public void getseatDeatilsById() {
		Seat seat=seatService.getSeatById(104);
		assertNotNull(seat);
		assertEquals("E1",seat.getSeatNumber());
	}
	
	@Test
	public void updateSeatDetailsById() {
	    Seat s1 = new Seat();
	    s1.setSeatType("Window");
	    s1.setClassType("Economy");
	    s1.setStatus("avialable");
	    s1.setSeatPrice(7500.00);
	    Seat updatedSeat = seatService.updateSeatById(104, s1);

	    assertNotNull(updatedSeat);
	    assertEquals("Window", updatedSeat.getSeatType());
	    assertEquals("Economy", updatedSeat.getClassType());
	    assertEquals("avialable", updatedSeat.getStatus());
	    assertEquals(7500.00, updatedSeat.getSeatPrice(), 0.01);
	}

}
