package com.mypackage.demo;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.Disabled;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mypackage.demo.model.Bankserver;
import com.mypackage.demo.service.BankserverService;


@SpringBootTest
class BankServerTest {
	@Autowired
	BankserverService bankserverService;
	
	@Disabled
	@Test
	public void getcCardNumber() {
		Bankserver bankserver=bankserverService.getDetailsById(1);
		assertNotNull(bankserver);
		assertEquals(1,bankserver.getId());
		
	}
	
	@Disabled
	@Test
	public void addBankDetails() {
		Bankserver bankserver=new Bankserver();
		bankserver.setcCardnumber(2347896732549019L);
		bankserver.setcCvvnumber(999);
		bankserver.setcUpi("Mohammed@ibl");
		bankserver.setExpiryDate(convertStringToDate("2025-11-09"));
		Bankserver bs=this.bankserverService.saveDetails(bankserver);
		assertNotNull(bs);
	}
	
	public Date convertStringToDate(String dateString) {
	    try {
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	        return sdf.parse(dateString);
	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	}
	
	@Disabled
	@Test
	public void findUpiId() {
		Bankserver bankserver=this.bankserverService.findByUpi("Mohammed@ibl");
		assertNotNull(bankserver);
	}
	
	@Test
	public void deleteBankDetails() {
		this.bankserverService.removerBankDetailsById(1);
		System.out.println("Deleted Successfully");
	}
	
}
