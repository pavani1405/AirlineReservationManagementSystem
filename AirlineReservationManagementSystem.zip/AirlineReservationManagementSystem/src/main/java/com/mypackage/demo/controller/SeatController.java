package com.mypackage.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.model.Seat;
import com.mypackage.demo.repository.PassengerRepository;

import com.mypackage.demo.service.SeatService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("api/Seat")
public class SeatController {
	@Autowired
	SeatService seatService;
	@Autowired
	PassengerRepository passengerRepository;
	
	@PostMapping
	public ResponseEntity<Seat> addSeats(@RequestBody Seat seat){
		return new ResponseEntity<Seat> (seatService.addSeat(seat),HttpStatus.CREATED);
	}
	@PostMapping("/flight/{flightId}/add-multiple-seats/{count}")
	public List<Seat> addMultipleSeatsToFlight(@RequestBody List<Seat> seats,@PathVariable int flightId,@PathVariable int count) {
	    return seatService.addSameSeatMultipleTimes(seats, flightId, count);
	}
	@PostMapping("/flight/{flightId}")
	public ResponseEntity<Seat> addSeatsToFlight(@PathVariable("flightId")int flightId,@RequestBody Seat seat){
		return new ResponseEntity<Seat> (seatService.addSeatToFlight(seat, flightId),HttpStatus.CREATED);
	}
	@GetMapping
	public List<Seat> getAllSeats(){
		return seatService.getAllSeats();
	}
	@GetMapping("/{seatId}")
	public ResponseEntity<Seat> getSeatById(@PathVariable("seatId") int seatId){
		return new ResponseEntity<Seat> (seatService.getSeatById(seatId),HttpStatus.OK);
	}
	@DeleteMapping("/{seatId}")
	public ResponseEntity<String> removeSeatById(@PathVariable("seatId") int seatId){
		seatService.removeSeatById(seatId);
		return new ResponseEntity<String>("Deleted Successfully",HttpStatus.OK);
	}
	@DeleteMapping("/getseatafterdeleting/{seatId}")
	public List<Seat> removeRouteById1(@PathVariable("seatId") int seatId){
		seatService.removeSeatById(seatId);
		return seatService.getAllSeats();
	}
	@PutMapping("/{seatId}")
	public ResponseEntity<Seat> updateSeatById(@PathVariable("seatId") int seatId,@RequestBody Seat seat){
		return new ResponseEntity<Seat> (seatService.updateSeatById(seatId,seat),HttpStatus.OK);
	}
	
	/*@PutMapping("/updatepassenger/{seatId}")
	public void updatepassengerIdbySeatId(@PathVariable("seatId") int seatId,@RequestBody int seatPassengerId) {
		seatService.updatePassengerBySeatid(seatId, seatPassengerId);
	}*/
	 @GetMapping("/flight/{flightId}")
	    public List<Seat> getSeatsByFlightId(@PathVariable int flightId) {
	        return seatService.getSeatsByFlightId(flightId);
	    }
	 
	 @PutMapping("/updateseatbyflight/{flightId}/{seatId}")
	 public ResponseEntity<Seat> updateSeatByFlightId(@PathVariable("flightId") int flightId,@PathVariable("seatId") int seatId,@RequestBody Seat seat) {

	     return new ResponseEntity<Seat>(seatService.updateSeatByFlightId(flightId, seatId, seat),HttpStatus.OK);
	 }
	  
	 
	 @DeleteMapping("/deleteseatbyflight/{flightId}/{seatId}")
	     public List<Seat> deleteSeatByFlightIdAndReturnUpdatedList(@PathVariable int flightId,@PathVariable int seatId) {

	         seatService.deleteSeatByFlightId(flightId, seatId);
	         return seatService.getSeatsByFlightId(flightId); // Returns updated seat list for that flight
	     }
	 @PutMapping("/updateSeatStatus/{flightId}/{seatNumber}")
	 public Seat updateSeatStatusbySeatNumberofFlight(@PathVariable("seatNumber")String seatNumber,@PathVariable("flightId") int flightId,@RequestBody Seat newSeatDetails) {
		 return seatService.updateSeatStatusbySeatNumberofFlight(flightId, seatNumber, newSeatDetails);
	 }

	 }


