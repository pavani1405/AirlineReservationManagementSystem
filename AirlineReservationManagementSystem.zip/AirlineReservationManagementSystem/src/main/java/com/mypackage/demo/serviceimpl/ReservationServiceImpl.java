package com.mypackage.demo.serviceimpl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mypackage.demo.model.CombinedResponseDTO;
import com.mypackage.demo.model.Flight;
import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.model.Reservation;
import com.mypackage.demo.model.User;
import com.mypackage.demo.repository.FlightRepository;
import com.mypackage.demo.repository.PassengerRepository;
import com.mypackage.demo.repository.ReservationRepository;
import com.mypackage.demo.repository.UserRepository;

import com.mypackage.demo.service.FlightService;
import com.mypackage.demo.service.PassengerService;
import com.mypackage.demo.service.ReservationService;
import com.mypackage.demo.service.UserService;

@Service
public class ReservationServiceImpl implements ReservationService {
	@Autowired
	ReservationRepository reservationRepository;
	@Autowired
	private UserService userService;
	@Autowired
	private PassengerService passengerService;
	@Autowired
	private EmailService emailService;
	
	 @Autowired
	    private PassengerRepository passengerRepository;
	 @Autowired
	 FlightService flightService;
	 @Autowired
	 FlightRepository flightRepository;

	
	@Override
	public Reservation addReservation(Reservation reservation) {
		// TODO Auto-generated method stub
		return reservationRepository.save(reservation);
	}
	

	@Override
	public List<Reservation> getAllReservation() {
		// TODO Auto-generated method stub
		return reservationRepository.findAll();
	}

	@Override
	public Reservation getReservationById(int rId) {
		// TODO Auto-generated method stub
		return reservationRepository.findById(rId).get();
	}

	@Override
	public void removeReservationById(int rId) {
		// TODO Auto-generated method stub
		Reservation reservation=getReservationById(rId);
		reservationRepository.deleteById(rId);
		
	}

	@Override
	public Reservation updateReservationById(int rId, Reservation newReservationDetails) {
		// TODO Auto-generated method stub
		Reservation existingReservationInfo=getReservationById(rId);
		existingReservationInfo.setReservationStatus(newReservationDetails.getReservationStatus());
		return reservationRepository.save(existingReservationInfo);
	}

	@Override
	public List<Passenger> getPassengersByUser(int user_Id) {
		// TODO Auto-generated method stub
		User user=userService.getUserById(user_Id);
		return user.getPassenger();
	}


	@Override
	public CombinedResponseDTO getReservationDetailsByReservationNumber(String reservationNumber) {
		// TODO Auto-generated method stub
		Reservation reservation = reservationRepository.findByReservationNumber(reservationNumber);

	    if (reservation == null) {
	        throw new RuntimeException("Reservation not found with number: " + reservationNumber);
	    }

	    // Fetch passengers
	    List<Passenger> passengers = passengerRepository.findByReservation_RId(reservation.getrId());

	    // Fetch flight
	    Flight flight = flightRepository.findById(reservation.getFlight().getFlightId())
	            .orElse(null);

	    CombinedResponseDTO responseDTO = new CombinedResponseDTO();
	    responseDTO.setReservationNumber(reservation.getReservationNumber());

	    // Passenger DTO mapping
	    List<CombinedResponseDTO.PassengerDTO> passengerDTOs = passengers.stream().map(p -> {
	        CombinedResponseDTO.PassengerDTO dto = new CombinedResponseDTO.PassengerDTO();
	        dto.setFirstName(p.getpFirstName());
	        dto.setLastName(p.getpFirstName());
	        dto.setEmail(p.getpEmail());
	        dto.setSeatNumber(p.getpSeatNumber());
	        return dto;
	    }).collect(Collectors.toList());
	    responseDTO.setPassengers(passengerDTOs);

	    // Flight DTO mapping
	    if (flight != null) {
	        CombinedResponseDTO.FlightDTO flightDTO = new CombinedResponseDTO.FlightDTO();
	        flightDTO.setFlightCode(flight.getFlightCode());
	        flightDTO.setDepartureTime(flight.getDepartureTime());
	        flightDTO.setArrivalTime(flight.getArrivalTime());
	        flightDTO.setDepartureAirport(flight.getDepartureAirport());
	        flightDTO.setArrivalAirport(flight.getArrivalAirport());
	        responseDTO.setFlight(flightDTO);
	    }

	    return responseDTO;
	}
	 
	@Override
    public List<CombinedResponseDTO> getReservationDetailsByUserId(int userId) {
        // Fetch all reservations by user ID
        List<Reservation> reservations = reservationRepository.findByUser_userId(userId);

        List<CombinedResponseDTO> responseDTOs = new ArrayList<>();

        for (Reservation reservation : reservations) {
            List<Passenger> passengers = passengerRepository.findByReservation_RId(reservation.getrId());
            Flight flight = flightRepository.findById(reservation.getFlight().getFlightId()).orElse(null);

            CombinedResponseDTO responseDTO = new CombinedResponseDTO();
            responseDTO.setReservationNumber(reservation.getReservationNumber());
            responseDTO.setReservationStatus(reservation.getReservationStatus());

            // Map passengers to DTO
            List<CombinedResponseDTO.PassengerDTO> passengerDTOs = passengers.stream().map(p -> {
                CombinedResponseDTO.PassengerDTO dto = new CombinedResponseDTO.PassengerDTO();
                dto.setFirstName(p.getpFirstName());
                dto.setLastName(p.getpLastName());
                dto.setEmail(p.getpEmail());
                dto.setSeatNumber(p.getpSeatNumber());
                return dto;
            }).collect(Collectors.toList());
            responseDTO.setPassengers(passengerDTOs);

            // Map flight details to DTO
            if (flight != null) {
                CombinedResponseDTO.FlightDTO flightDTO = new CombinedResponseDTO.FlightDTO();
                flightDTO.setFlightCode(flight.getFlightCode());
                flightDTO.setDepartureTime(flight.getDepartureTime());
                flightDTO.setArrivalTime(flight.getArrivalTime());
                flightDTO.setDepartureAirport(flight.getDepartureAirport());
                flightDTO.setArrivalAirport(flight.getArrivalAirport());
                responseDTO.setFlight(flightDTO);
            }

            responseDTOs.add(responseDTO);
        }

        return responseDTOs;
    }
	  
	
	  /*@Override
	    public boolean cancelReservationByNumber(String reservationNumber) {
	        Reservation reservation = reservationRepository.findByReservationNumber(reservationNumber);

	        if (reservation == null) {
	            return false;
	        }

	        reservation.setReservationStatus("CANCELED");
	        reservationRepository.save(reservation);
	        return true;
	    }*/

	    @Override
	    public Reservation findByReservationNumber(String reservationNumber) {
	        return reservationRepository.findByReservationNumber(reservationNumber);
	    }
	    
	    @Override
	    public boolean updateReservation(Reservation reservation) {
	        reservationRepository.save(reservation);

	        if ("CANCELED".equalsIgnoreCase(reservation.getReservationStatus())) {
	            List<Passenger> passengers = reservation.getPassengers();
	            Flight flight = reservation.getFlight();

	            if (passengers != null && !passengers.isEmpty()) {
	                for (Passenger passenger : passengers) {
	                    if (passenger.getpEmail() != null && !passenger.getpEmail().isEmpty()) {
	                        String to = passenger.getpEmail();
	                        String subject = "Flight Reservation Cancelled - " + reservation.getReservationNumber();

	                        String message = "Hi <b>" + passenger.getpFirstName() + " " + passenger.getpLastName() + "</b>,<br><br>" +
	                            "We regret to inform you that your flight reservation has been <span style='color:red;'><b>cancelled</b></span>.<br><br>" +

	                            "<b>Reservation Number:</b> " + reservation.getReservationNumber() + "<br>" +
	                            "<b>Flight Code:</b> " + flight.getFlightCode() + "<br><br>" +

	                            "<b>Departure Details:</b><br>" +
	                            "&nbsp;&nbsp;<b>Airport:</b> " + flight.getDepartureAirport() + "<br>" +
	                            "&nbsp;&nbsp;<b>Date:</b> " + extractDate(flight.getDepartureTime()) + "<br>" +
	                            "&nbsp;&nbsp;<b>Time:</b> " + extractTime(flight.getDepartureTime()) + "<br><br>" +

	                            "<b>Arrival Details:</b><br>" +
	                            "&nbsp;&nbsp;<b>Airport:</b> " + flight.getArrivalAirport() + "<br>" +
	                            "&nbsp;&nbsp;<b>Date:</b> " + extractDate(flight.getArrivalTime()) + "<br>" +
	                            "&nbsp;&nbsp;<b>Time:</b> " + extractTime(flight.getArrivalTime()) + "<br><br>" +

	                            "<b>Seat Number:</b> " + passenger.getpSeatNumber() + "<br><br>" +

	                            "<span style='color: #E74C3C;'><b>If you have any questions or concerns, please contact our support team.</b></span><br><br>" +

	                            "<div style='text-align:center; margin-top: 30px;'>" +
	                            "<h2 style='color: #2E86C1;'>We hope to fly with you again,</h2>" +
	                            "<span style='color: #8E44AD; font-weight: bold;'>SkyHigh Airline ✈️</span>" +
	                            "</div>";

	                        emailService.sendEmail(to, subject, message);
	                    }
	                }
	            }
	        }

	        return true;
	    }
	    
	    private String extractDate(String dateTimeStr) {
	        LocalDateTime dateTime = LocalDateTime.parse(dateTimeStr);
	        return dateTime.toLocalDate().toString();
	    }

	    private String extractTime(String dateTimeStr) {
	        LocalDateTime dateTime = LocalDateTime.parse(dateTimeStr);
	        return dateTime.toLocalTime().withSecond(0).withNano(0).toString();
	    }

	    
	    
	    @Override
	    public Reservation findFirstByReservationNumber(String reservationNumber) {
	        List<Reservation> reservations = reservationRepository.findReservationsByReservationNumber(reservationNumber);
	        return reservations.isEmpty() ? null : reservations.get(0);  // Pick first or handle logic here
	    }

}
