package com.mypackage.demo.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;


@Entity
@Table(name = "seat")
public class Seat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seat_id")
    private int seatId;
    @Column(name = "seat_type")
    private String seatType; // e.g., Window, Aisle, Middle
    @Column(name="seat_number")
    private String seatNumber;

    @Column(name = "class_type")
    private String classType; // e.g., Economy, Business, First Class

    @Column(name = "status")
    private String status; // e.g., Available, Reserved, Booked
    
    @Column(name="seatPrice")
    private double seatPrice;
    
    @Column(name="passenger_Id")
    private int seatPassengerId;

    // Many-to-one relationship with Flight (Each seat belongs to one flight)
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flight_id")
    private Flight flight;

    // Many-to-one relationship with Passenger (Each seat can be reserved by one passenger)
  
    // Getters and setters

    public int getSeatId() {
        return seatId;
    }

    public void setSeatId(int seatId) {
        this.seatId = seatId;
    }
    public String getSeatType() {
        return seatType;
    }

    public void setSeatType(String seatType) {
        this.seatType = seatType;
    }

    public String getClassType() {
        return classType;
    }

    public void setClassType(String classType) {
        this.classType = classType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

	public double getSeatPrice() {
		return seatPrice;
	}

	public void setSeatPrice(double seatPrice) {
		this.seatPrice = seatPrice;
	}

	public int getSeatPassengerId() {
		return seatPassengerId;
	}

	public void setSeatPassengerId(int seatPassengerId) {
		this.seatPassengerId = seatPassengerId;
	}

	public String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}
    

   
}
