package com.mypackage.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mypackage.demo.model.Seat;

import jakarta.transaction.Transactional;

@Repository
public interface SeatRepository extends JpaRepository<Seat,Integer>{
	//update  passengerId by seatId in seat
	@Transactional
	@Modifying
	@Query(value = "UPDATE seat SET passenger_id = ?2 WHERE seat_id = ?1", nativeQuery = true)
	public void updatePassengerBySeatId(int seatId, int seatPassengerId);
	
	public Seat findByFlightFlightIdAndSeatId(int flightId, int seatId);
	
	public Seat findByFlightFlightIdAndSeatNumber(int flightId,String seatNumber);
	
	
	public List<Seat> findByFlightFlightId(int flightId);
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM seat WHERE flight_id = ?1 AND seat_id = ?2", nativeQuery = true)
	void deleteSeatByFlightId(int flightId, int seatId);
	public Seat findBySeatNumberAndFlight_FlightId(String seatNumber, int flightId);
	
	@Query(value = "SELECT * FROM seat WHERE flight_id = ?1", nativeQuery = true)
	public List<Seat> findSeatsByFlightId(int flightId);
	
	
	public List<Seat> findBySeatNumber(String seatNumber); // In case seat numbers repeat per flight



}
