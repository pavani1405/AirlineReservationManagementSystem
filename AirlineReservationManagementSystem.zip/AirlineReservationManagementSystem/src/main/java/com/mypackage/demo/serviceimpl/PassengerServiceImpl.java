package com.mypackage.demo.serviceimpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mypackage.demo.model.Flight;
import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.model.Reservation;
import com.mypackage.demo.model.Seat;
import com.mypackage.demo.model.User;
import com.mypackage.demo.repository.PassengerRepository;
import com.mypackage.demo.repository.ReservationRepository;
import com.mypackage.demo.repository.UserRepository;
import com.mypackage.demo.service.FlightService;
import com.mypackage.demo.service.PassengerService;
import com.mypackage.demo.service.SeatService;
import com.mypackage.demo.service.UserService;

import jakarta.transaction.Transactional;

@Service
public class PassengerServiceImpl implements PassengerService{
	@Autowired
	private PassengerRepository passengerRepository;
	@Autowired
	private UserService userService;
	@Autowired
	private SeatService seatService;
	@Autowired
	EmailService emailService;
	
	@Autowired
	private FlightService flightService;
	
	@Autowired
	private ReservationRepository reservationRepository;

	@Override
	public Passenger addPassenger(Passenger passenger) {
		// TODO Auto-generated method stub
		return passengerRepository.save(passenger);
	}
	@Override
	public Passenger addPassengerToUser(Passenger passenger,int UserId) {
		// TODO Auto-generated method stub
		User user=userService.getUserById(UserId);
		passenger.setUser(user);
		return passengerRepository.save(passenger);
	}
	
	 @Transactional
	    @Override
	    public List<Passenger> addPassengersToUser(List<Passenger> passengers, int userId, int flightId) {
	        // Step 1: Fetch User and Flight
	        User user = userService.getUserById(userId);
	        Flight flight = flightService.getFlightById(flightId);

	        if (user == null || flight == null) {
	            throw new IllegalArgumentException("User or Flight not found");
	        }

	        // Step 2: Create Reservation
	        Reservation reservation = new Reservation();
	        reservation.setReservationNumber(UUID.randomUUID().toString().substring(0, 8).toUpperCase());
	        reservation.setReservationStatus("CONFIRMED");
	        reservation.setUser(user);
	        reservation.setFlight(flight);
	        reservation = reservationRepository.save(reservation);

	        // Step 3: Link each passenger to user and reservation
	        for (Passenger passenger : passengers) {
	            passenger.setUser(user);
	            passenger.setReservation(reservation);
	        }

	        // Step 4: Save passengers
	        List<Passenger> savedPassengers = passengerRepository.saveAll(passengers);

	        // Step 5: Book seats
	        for (Passenger passenger : savedPassengers) {
	            String seatNumber = passenger.getpSeatNumber();
	            if (seatNumber != null) {
	                seatService.markSeatAsBooked(seatNumber, flightId);
	            }
	        }

	        // Step 6: Send email
	        for (Passenger passenger : savedPassengers) {
	            if (passenger.getpEmail() == null) continue;

	            String message = "Hi <b>" + passenger.getpFirstName() + " " + passenger.getpLastName() + "</b>,<br><br>" +
	            	    "Your ticket has been successfully booked with the following details:<br><br>" +

	            	    "<b>Reservation Number:</b> " + reservation.getReservationNumber() + "<br>" +
	            	    "<b>Flight Code:</b> " + flight.getFlightCode() + "<br><br>" +

	            	    "<b>Departure Details:</b><br>" +
	            	    "&nbsp;&nbsp;<b>Airport:</b> " + flight.getDepartureAirport() + "<br>" +
	            	    "&nbsp;&nbsp;<b>Date:</b> " + extractDate(flight.getDepartureTime()) + "<br>" +
	            	    "&nbsp;&nbsp;<b>Time:</b> " + extractTime(flight.getDepartureTime()) + "<br><br>" +

	            	    "<b>Arrival Details:</b><br>" +
	            	    "&nbsp;&nbsp;<b>Airport:</b> " + flight.getArrivalAirport() + "<br>" +
	            	    "&nbsp;&nbsp;<b>Date:</b> " + extractDate(flight.getArrivalTime()) + "<br>" +
	            	    "&nbsp;&nbsp;<b>Time:</b> " + extractTime(flight.getArrivalTime()) + "<br><br>" +

	            	    "<b>Seat Number:</b> " + passenger.getpSeatNumber() + "<br><br>" +

	            	    "<div style='text-align:center; margin-top: 30px;'>" +
	            	    "<h2 style='color: #2E86C1;'>Fly High, " +
	            	    "<span style='color: #27AE60;'>Fly Safe, </span>" +
	            	    "<span style='color: #8E44AD;'>Fly <b>SkyHigh Airline</b> ✈️</span></h2>" +
	            	    "</div>" +
	            	    "<hr style='margin-top:30px;'>" +
	            	    "<div style='font-size: 13px; color: red; margin-top: 20px;'>" +
	            	    "<b>Terms and Conditions:</b><br><br>" +
	            	    "- Ticket cancellation is allowed only if requested at least <b style='font-size:14px; color:darkred;'>24 hours</b> before the scheduled departure time.<br>" +
	            	    "- No cancellations or refunds will be entertained if less than <b style='font-size:14px; color:darkred;'>24 hours</b> remain before departure.<br>" +
	            	    "- Cancellation policies may vary for special or promotional fares.<br>" +
	            	    "- For assistance, please contact us at: <a href='mailto:support@skyhighairline.com' style='color:darkred; text-decoration:none;'>support@skyhighairline.com</a><br>" +
	            	    "</div>";


	            String subject = "Your Flight Ticket Confirmation - " + flight.getFlightCode();
	            emailService.sendEmail(passenger.getpEmail(), subject, message);
	        }

	        return savedPassengers;
	    }

	  private String extractDate(String isoDateTime) {
	        LocalDateTime ldt = LocalDateTime.parse(isoDateTime);
	        return ldt.toLocalDate().toString(); // yyyy-MM-dd
	    }

	    private String extractTime(String isoDateTime) {
	        LocalDateTime ldt = LocalDateTime.parse(isoDateTime);
	        return ldt.toLocalTime().toString(); // HH:mm:ss
	    }


	@Override
	public List<Passenger> getAllPassenger() {
		// TODO Auto-generated method stub
		return passengerRepository.findAll();
	}

	@Override
	public Passenger getPassengerById(int pId) {
		// TODO Auto-generated method stub
		return passengerRepository.findById(pId).get();
	}

	@Override
	public void removePassengerById(int pId) {
		// TODO Auto-generated method stub
		Passenger passenger=getPassengerById(pId);
		passengerRepository.deleteById(pId);
		
	}

	@Override
	public Passenger updatePassengerById(int pId, Passenger newpassengerDetails) {
		// TODO Auto-generated method stub
		Passenger existingPassengerInfo=getPassengerById(pId);
		existingPassengerInfo.setpFirstName(newpassengerDetails.getpFirstName());
		existingPassengerInfo.setpLastName(newpassengerDetails.getpLastName());
		existingPassengerInfo.setpEmail(newpassengerDetails.getpEmail());
		existingPassengerInfo.setpMobileNo(newpassengerDetails.getpMobileNo());
		existingPassengerInfo.setpAge(newpassengerDetails.getpAge());
		existingPassengerInfo.setpGender(newpassengerDetails.getpGender());
		existingPassengerInfo.setpPassportNo(newpassengerDetails.getpPassportNo());
		return passengerRepository.save(existingPassengerInfo);
	}
	
	
	 @Override
	    public List<Passenger> getPassengersByReservationNumber(String reservationNumber) {
	        return passengerRepository.findPassengersByReservationNumber(reservationNumber);
	    }
	 
	   @Override
	    public List<Passenger> searchPassengers(String searchTerm) {
	        return passengerRepository.searchPassengers(searchTerm);
	    }
	 
	

	 }

	
