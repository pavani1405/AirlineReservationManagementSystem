package com.mypackage.demo.service;

import java.util.List;

import com.mypackage.demo.model.Bankserver;

public interface BankserverService {
	
	 public Bankserver saveDetails(Bankserver bankserver);

	 public Bankserver findByCardCvv(Long cCardnumber, Integer cCvvnumber, String expiryDate);
	 
	 public Bankserver getDetailsById(int id);
	 public List<Bankserver> getAllDetails();
	 
	 public void removerBankDetailsById(int id);
	Bankserver findByUpi(String cUpi);
}
