package com.mypackage.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.mypackage.demo.model.Flight;
import com.mypackage.demo.repository.FlightRepository;

import com.mypackage.demo.service.FlightService;

@Service
public class FlightServiceImpl implements FlightService{
	@Autowired
	FlightRepository flightRepository;

	
	@Override
	public Flight addFlight(Flight flight) {
		// TODO Auto-generated method stub
		return flightRepository.save(flight);
	}
	

	@Override
	public List<Flight> getallFlight() {
		// TODO Auto-generated method stub
		return flightRepository.findAll();
	}

	@Override
	public Flight getFlightById(int flightId) {
		// TODO Auto-generated method stub
		return flightRepository.findById(flightId).get();
	}

	@Override
	public void removeFlightById(int flightId) {
		// TODO Auto-generated method stub
		Flight flight=getFlightById(flightId);
		flightRepository.deleteById(flightId);
		
	}

	@Override
	public Flight updateFlightById(int flightId, Flight newflight) {
		// TODO Auto-generated method stub
		Flight existingflight=getFlightById(flightId);
		existingflight.setFlightCode(newflight.getFlightCode());
		existingflight.setArrivalAirport(newflight.getArrivalAirport());
		existingflight.setDepartureAirport(newflight.getDepartureAirport());
		existingflight.setArrivalTime(newflight.getArrivalTime());
		existingflight.setDepartureTime(newflight.getDepartureTime());
		existingflight.setFlightAirline(newflight.getFlightAirline());
		existingflight.setFlightAirlineCountry(newflight.getFlightAirlineCountry());
		existingflight.setTotalSeats(newflight.getTotalSeats());
		//existingflight.setSeats(newflight.getSeats());	
		return flightRepository.save(existingflight);
	}
	
	@Override
	public List<Flight> searchFlightsByFromAndTo(String departureAirport, String arrivalAirport) {
	    return flightRepository.findByDepartureAirportIgnoreCaseAndArrivalAirportIgnoreCase(departureAirport, arrivalAirport);
	}
	
	@Override
	public List<Flight> getFlightsWithAvailableSeats() {
	    return flightRepository.findFlightsWithAvailableSeats();
	}


}
