package com.mypackage.demo.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.mypackage.demo.model.Flight;
import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.model.Seat;
import com.mypackage.demo.repository.FlightRepository;
import com.mypackage.demo.repository.SeatRepository;
import com.mypackage.demo.service.FlightService;
import com.mypackage.demo.service.PassengerService;
import com.mypackage.demo.service.SeatService;

@Service
public class SeatServiceImpl implements SeatService{
	@Autowired
	SeatRepository seatRepository;
	@Autowired
	@Lazy
	PassengerService passengerService;
	@Autowired
	FlightRepository flightRepository;
	
	@Autowired 
	FlightService flightService;
	
	@Override
	public Seat addSeat(Seat seat) {
		// TODO Auto-generated method stub
		
		return seatRepository.save(seat);
	}
	
	@Override
	public Seat addSeatToFlight(Seat seat, int flightId) {
		// TODO Auto-generated method stub
		Flight flight=flightService.getFlightById(flightId);
		seat.setFlight(flight);
		return seatRepository.save(seat);
	}
	@Override
	public List<Seat> addSameSeatMultipleTimes(List<Seat> seats, int flightId, int count) {
	    Flight flight = flightService.getFlightById(flightId);

	    // Fetch existing seats for the flight
	    List<Seat> existingSeats = seatRepository.findByFlightFlightId(flightId);

	    int totalExistingSeats = existingSeats.size();

	    List<Seat> newSeats = new ArrayList<>();

	    // Use template from first seat
	    if (!seats.isEmpty()) {
	        Seat template = seats.get(0);

	        for (int i = 0; i < count; i++) {
	            int seatIndex = totalExistingSeats + i;
	            String seatNumber = generateAlphanumericSeatNumber(seatIndex, 6); // 6 seats per row

	            Seat seat = new Seat();
	            seat.setSeatNumber(seatNumber);
	            seat.setSeatType(template.getSeatType());
	            seat.setClassType(template.getClassType());
	            seat.setStatus(template.getStatus());
	            seat.setSeatPrice(template.getSeatPrice());
	            //seat.setSeatPassengerId(null);
	            seat.setFlight(flight);
	            newSeats.add(seat);
	        }
	    }

	    return seatRepository.saveAll(newSeats);
	}

	// Helper to generate A1, A2, ..., B1, etc.
	private String generateAlphanumericSeatNumber(int index, int seatsPerRow) {
	    int row = index / seatsPerRow;
	    int col = index % seatsPerRow + 1;
	    char rowChar = (char) ('A' + row);
	    return rowChar + String.valueOf(col);
	}

	@Override
	public List<Seat> getAllSeats() {
		// TODO Auto-generated method stub
		return seatRepository.findAll();
	}

	@Override
	public Seat getSeatById(int seatId) {
		// TODO Auto-generated method stub
		return seatRepository.findById(seatId).get();
	}

	@Override
	public void removeSeatById(int seatId) {
		// TODO Auto-generated method stub
		Seat seat=getSeatById(seatId);
		seatRepository.deleteById(seatId);
		}
	@Override
	public Seat updateSeatById(int seatId, Seat newSeatDetails) {
		// TODO Auto-generated method stub
		Seat existingSeatInfo=getSeatById(seatId);
		existingSeatInfo.setClassType(newSeatDetails.getClassType());
		existingSeatInfo.setSeatType(newSeatDetails.getSeatType());
		existingSeatInfo.setStatus(newSeatDetails.getStatus());
		existingSeatInfo.setFlight(newSeatDetails.getFlight());
		existingSeatInfo.setSeatPassengerId(newSeatDetails.getSeatPassengerId());
		existingSeatInfo.setSeatPrice(newSeatDetails.getSeatPrice());
		return seatRepository.save(existingSeatInfo);
	}

	@Override
	public Seat updateSeatByFlightId(int flightId, int seatId, Seat newSeatDetails) {
	    Seat existingSeat = seatRepository.findByFlightFlightIdAndSeatId(flightId, seatId);

	    if (existingSeat != null) {
	        existingSeat.setClassType(newSeatDetails.getClassType());
	        existingSeat.setSeatType(newSeatDetails.getSeatType());
	        existingSeat.setStatus(newSeatDetails.getStatus());
	        Flight flight=flightService.getFlightById(flightId);
	        existingSeat.setFlight(flight);
	        existingSeat.setSeatPrice(newSeatDetails.getSeatPrice());
	        return seatRepository.save(existingSeat); // ✅ return updated seat
	    } else {
	        throw new RuntimeException("Seat not found with ID: " + seatId + " and Flight ID: " + flightId);
	    }
	}


	/*@Override
	public void updatePassengerBySeatid(int seatId, int seatPassengerId) {
		// TODO Auto-generated method stub
		seatRepository.updatePassengerBySeatId(seatId, seatPassengerId);
	}*/
	 @Override
	    public List<Seat> getSeatsByFlightId(int flightId) {
	        return seatRepository.findByFlightFlightId(flightId);
	    }
	


	 @Override
	 public void deleteSeatByFlightId(int flightId, int seatId) {
	     seatRepository.deleteSeatByFlightId(flightId, seatId);
	 }
	 @Override
	 public void markSeatAsBooked(String seatNumber, int flightId) {
		    Seat seat = seatRepository.findBySeatNumberAndFlight_FlightId(seatNumber, flightId);
		    if (seat != null) {
		        seat.setStatus("Booked");
		        seatRepository.save(seat);
		    }
		}

	@Override
	public Seat updateSeatStatusbySeatNumberofFlight(int flightId, String seatNumber, Seat newSeatDetails) {
		// TODO Auto-generated method stub
		Seat existingSeat=seatRepository.findByFlightFlightIdAndSeatNumber(flightId, seatNumber);
		existingSeat.setStatus(newSeatDetails.getStatus());
		return seatRepository.save(existingSeat);
	}
	
	@Override
	public void updateSeatStatusToAvailable(String seatNumber) {
	    List<Seat> seats = seatRepository.findBySeatNumber(seatNumber);

	    for (Seat seat : seats) {
	        if (!"AVAILABLE".equalsIgnoreCase(seat.getStatus())) {
	            seat.setStatus("Available");
	            seatRepository.save(seat); // Save updated seat
	        }
	    }
	}


	
	
	
	 }

