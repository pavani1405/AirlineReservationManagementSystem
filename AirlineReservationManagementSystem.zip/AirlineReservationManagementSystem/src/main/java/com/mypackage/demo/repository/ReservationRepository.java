package com.mypackage.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mypackage.demo.model.Reservation;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation,Integer> {
	
	public Reservation findByReservationNumber(String reservationNumber);
	
	List<Reservation> findByUser_userId(int userId);

	public List<Reservation> findReservationsByReservationNumber(String reservationNumber);
}
