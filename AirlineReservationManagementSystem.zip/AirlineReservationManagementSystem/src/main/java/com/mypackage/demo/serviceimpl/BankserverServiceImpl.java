package com.mypackage.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mypackage.demo.model.Bankserver;
import com.mypackage.demo.repository.BankserverRepository;
import com.mypackage.demo.service.BankserverService;



@Service
public class BankserverServiceImpl implements BankserverService{

	
	@Autowired
	private BankserverRepository bankserverRepositry;
	
	@Override
	public Bankserver saveDetails(Bankserver bankserver) {
		
		return bankserverRepositry.save(bankserver);
	}
	@Override
	public Bankserver findByCardCvv(Long cCardnumber, Integer cCvvnumber,String expiryDate) {
		return bankserverRepositry.findByCardCvv(cCardnumber, cCvvnumber, expiryDate);
	}
	
	@Override
	public Bankserver findByUpi(String cUpi) {
		
		return bankserverRepositry.findByUpi(cUpi);
	}
	@Override
	public Bankserver getDetailsById(int id) {
		// TODO Auto-generated method stub
		return bankserverRepositry.findById(id).get();
	}
	@Override
	public void removerBankDetailsById(int id) {
		// TODO Auto-generated method stub
		
		Bankserver bs=getDetailsById(id);
	bankserverRepositry.deleteById(id);;
	}
	@Override
	public List<Bankserver> getAllDetails() {
		// TODO Auto-generated method stub
		return bankserverRepositry.findAll();
	}
	
}
