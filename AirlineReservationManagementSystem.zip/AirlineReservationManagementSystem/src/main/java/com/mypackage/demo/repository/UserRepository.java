package com.mypackage.demo.repository;

import java.util.Optional;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;


import com.mypackage.demo.model.User;

import jakarta.transaction.Transactional;

@Repository
public interface UserRepository extends JpaRepository<User,Integer> {
	
	public User findByUserEmailAndUserPassword(String userEmail,String userPassword);
	
	
	@Query(value = "select * from user_table e where e.email_address= ?",nativeQuery = true)
	public Optional<User> findByEmail(String userEmail);
	
	@Query(value = "select * from user_table b where b.mobile_no=?",nativeQuery = true)
	public User finfByPhone(String userMobileNo);
	
	@Query(value = "select * from user_table a where (a.email_address=?1 or a.mobile_no=?1) && a.favourite=?2",nativeQuery = true)
	public User findByEmailAndFav(String userEmail, String userFavourite);
	
	@Transactional
	@Modifying
	@Query(value = "update user_table a set a.password=?2 where a.email_address=?1",nativeQuery = true)
	public void updatepassByMail(String userEmail, String newPassword);
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE user_table a  SET a.fisrt_name =?1, a.last_name =?2,a.mobile_no =?3, a.password = ?4 , a.passport_no =?5  WHERE email_address =?6", nativeQuery = true)
	public void updateUserByEmail(String userFirstName,String userLastName,String userMobileNo,String userPassword,String userPassportNo,String userEmail,User user );
	
}
