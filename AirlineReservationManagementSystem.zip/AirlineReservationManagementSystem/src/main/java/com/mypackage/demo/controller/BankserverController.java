package com.mypackage.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mypackage.demo.model.Bankserver;
import com.mypackage.demo.service.BankserverService;



@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("api/Bankserver")

public class BankserverController {
	
	@Autowired
	private BankserverService bankserverService;
	
	@PostMapping("/savebank")
	public Bankserver saveDetails(@RequestBody Bankserver bankserver) {
		return bankserverService.saveDetails(bankserver);
		
	}
	
	
	//find by card
	@GetMapping("/findcardnumcvv/{cnum}/{cvv}/{date}")
	public Bankserver findByCardCvv(@PathVariable("cnum") Long cCardnumber,@PathVariable("cvv") Integer cCvvnumber,@PathVariable("date") String expiryDate) {
		return bankserverService.findByCardCvv(cCardnumber,cCvvnumber,expiryDate);
	
		
	}
	@GetMapping("/findById/{id}")
	public Bankserver getDetailsById(@PathVariable("id") int id) {
		return bankserverService.getDetailsById(id);
	}
	//find by upi
	@GetMapping("/findbyupi/{upi}")
	public Bankserver findByUpi(@PathVariable("upi") String cUpi) {
		return bankserverService.findByUpi(cUpi);
	}
	
	@GetMapping
	public List<Bankserver> getAllDetails(){
		return bankserverService.getAllDetails();
	}
	
	@DeleteMapping("getalldetailsafterdeleting/{id}")
	public List<Bankserver> getBankDetailsAfterDeleting(@PathVariable("id") int id) {
		bankserverService.removerBankDetailsById(id);
		return bankserverService.getAllDetails();
		
	}
	
}
