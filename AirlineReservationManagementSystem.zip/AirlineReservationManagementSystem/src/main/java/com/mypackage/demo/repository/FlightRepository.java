package com.mypackage.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mypackage.demo.model.Flight;

@Repository
public interface FlightRepository extends JpaRepository<Flight,Integer> {
	
	public List<Flight> findByDepartureAirportIgnoreCaseAndArrivalAirportIgnoreCase(String departureAirport, String arrivalAirport);
	
	 Optional<Flight> findById(int flightId);
	 
	 @Query(value = "SELECT DISTINCT f.* FROM flight f " +
             "JOIN seat s ON f.flight_id = s.flight_id " +
             "WHERE s.status = 'available'", nativeQuery = true)
 public List<Flight> findFlightsWithAvailableSeats();

}
